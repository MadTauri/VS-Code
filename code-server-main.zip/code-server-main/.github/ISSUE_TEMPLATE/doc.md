---
name: Documentation improvement
about: Suggest a documentation improvement
title: "[Docs]: "
labels: "docs"
assignees: "@jsjoeio"
---

## What is your suggestion?

## How will this improve the docs?

## Are you interested in submitting a PR for this?
