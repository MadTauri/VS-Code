---
name: Feature request
about: Suggest an idea to improve code-server
title: "[Feat]: "
labels: enhancement
assignees: ""
---

## What is your suggestion?

## Why do you want this feature?

## Are there any workarounds to get this functionality today?

## Are you interested in submitting a PR for this?
