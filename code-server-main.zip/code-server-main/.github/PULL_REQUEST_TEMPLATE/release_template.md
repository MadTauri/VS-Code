<!-- Note: this variable $CODE_SERVER_VERSION_TO_UPDATE will be set when you run the release-prep.sh script with `yarn release:prep` -->

This PR is to generate a new release of `code-server` at `$CODE_SERVER_VERSION_TO_UPDATE`

## Screenshot

TODO

## TODOs

Follow "Publishing a release" steps in `ci/README.md`

<!-- Note some of these steps below are redundant since they're listed in the "Publishing a release" docs -->

- [ ] update `CHANGELOG.md`
- [ ] manually run "Draft release" workflow after merging this PR
- [ ] merge PR opened in [code-server-aur](https://github.com/coder/code-server-aur)
