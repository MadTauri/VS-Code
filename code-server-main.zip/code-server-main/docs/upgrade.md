# Upgrade

To upgrade code-server, install the new version over the old version. All user
data is in `~/.local/share/code-server`, so they are preserved between
installations.
