module.exports = {
  settings: {
    "import/resolver": {
      typescript: {
        project: __dirname,
      },
    },
  },
}
